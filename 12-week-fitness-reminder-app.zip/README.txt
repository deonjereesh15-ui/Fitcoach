12-WEEK FITNESS REMINDER APP

This is an installable web app based on the supplied fitness blueprint.

How to use:
1. Put these files on any HTTPS web host.
2. Open the site on your phone.
3. Add it to the Home Screen.
4. Open it and tap Enable notifications.
5. Tap Test notification.

Important: browser/iPhone notification scheduling is limited. This version checks reminders while the app is running/open. A fully reliable background notification system needs a push-notification server or a native iOS/Android app.
